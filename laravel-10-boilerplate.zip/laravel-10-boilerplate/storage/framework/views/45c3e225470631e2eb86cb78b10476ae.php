<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Account/</span>Users List</h4>
    <div class="card">
        <h5 class="card-header">Users List</h5>
        <div class="table-responsive text-nowrap pb-2">
            
                <table class="table" style="width:100%" id="user_list">
                    <thead>
                        <tr>
                            <th>#ID</th>
                            <th>Full Name</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Create At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e('#' . $key + 1); ?></td>
                            <td>
                                <strong><?php echo e(Str::ucfirst($item->first_name) . ' ' . Str::ucfirst($item->last_name ??
                                    ' ')); ?> </strong>
                            </td>
                            <td>
                                <?php if($item->profile_image): ?>
                                <img src="<?php echo e($item->profile_image); ?>" alt="user" style="width:35px"
                                    class="rounded mr-2">
                                <?php else: ?>
                                <img src="<?php echo e(asset('admin/assets/img/avatars/1.png')); ?>" alt="user" style="width:35px"
                                    class="rounded mr-2">
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-label-primary me-1">Active</span></td>
                            <td>
                                <?php echo e($item->created_at->format('d/m/Y')); ?>

                            </td>
                            <td>
                                
                                <button type="button" class="btn btn-danger deleteUserBtn" data-href="<?php echo e(route('delete.user', $item->id)); ?>">
                                    <i class="bx bx-trash me-1"></i>Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('.deleteUserBtn').click(function (){
       let deleteUrl = $(this).data('href');
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = deleteUrl;
                Swal.fire({
                    title: "Deleted!",
                    text: "Your file has been deleted.",
                    icon: "success"
                });
            }
        });
    });
    $(function() {
        $('#user_list').DataTable({
            pageLength: 10,
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-10-boilerplate\resources\views/admin/user/user-list.blade.php ENDPATH**/ ?>