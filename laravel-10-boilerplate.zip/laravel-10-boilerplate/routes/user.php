<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Frontend\{AuthController};

Route::match(['GET', 'POST'], '/login', [AuthController::class, 'loginForm'])->name('user.login');
