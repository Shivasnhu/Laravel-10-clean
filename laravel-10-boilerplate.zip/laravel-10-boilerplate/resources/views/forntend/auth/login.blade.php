@extends('auth.layout')
@section('content')
    <div class="layout-login__form bg-white" data-perfect-scrollbar>
        <div class="d-flex justify-content-center mt-2 mb-5 navbar-light">
            <a href="#" class="navbar-brand" style="min-width: 0">
                <img class="navbar-brand-icon" src="{{ asset('public/assets/images/stack-logo-blue.svg') }}" width="25"
                    alt="Chatbot">
                <span>Chatbot</span>
            </a>
        </div>

        <h4 class="m-0">Welcome back!</h4>
        <p class="mb-5">Login to access your Chatbot Account </p>

        <form id="loginForm" action="{{ route('custom.login') }}" method="POST">
            @csrf
            <div class="form-group">
                <label class="text-label" for="email_2">Email Address:</label>
                <div class="input-group input-group-merge">
                    <input id="email_2" type="email" name="email" class="form-control form-control-prepended"
                        placeholder="Enter your emial address" value="{{ old('email') }}">
                    @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <span class="far fa-envelope"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="text-label" for="password_2">Password:</label>
                <div class="input-group input-group-merge">
                    <input id="password_2" type="password" name="password" class="form-control form-control-prepended"
                        placeholder="Enter your password" value="{{ old('password') }}">
                    @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <span class="fa fa-key"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group mb-5">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" checked="" id="remember">
                    <label class="custom-control-label" for="remember">Remember me</label>
                </div>
            </div>
            <div class="form-group text-center">
                <button class="btn btn-primary mb-5 " type="submit">Login</button><br>
                <a href="{{ route('forget.password.get') }}">Forgot password?</a> <br>
                Don't have an account? <a class="text-body text-underline" href="{{ route('signup.view') }}">Sign up!</a>
            </div>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        // Form submit
        $(document).on('submit', '#loginForm', function(e) {
            e.preventDefault();
            var form = $(this).closest('form');
            $.ajax({
                data: form.serialize(),
                url: form.attr('action'),
                type: "POST",
                dataType: "json",
                success: function(res) {
                    console.log(res);
                    if (res.errors) {
                        toastr.error(res.errors, 'Error', {
                            closeButton: true,
                            progressBar: true
                        });
                    } else {
                        window.location.href = res.url;
                    }
                },
                error: function(result) {
                    console.log(result);
                }
            })

            return false;


        });
    </script>
@endsection
