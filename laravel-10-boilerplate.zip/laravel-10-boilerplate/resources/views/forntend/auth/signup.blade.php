 @extends('auth.layout')
 @section('content')
     <div class="layout-login__form bg-white" data-perfect-scrollbar>
         <div class="d-flex justify-content-center mt-2 mb-5 navbar-light">
             <a href="#" class="navbar-brand" style="min-width: 0">
                 <img class="navbar-brand-icon" src="{{ asset('public/assets/images/stack-logo-blue.svg') }}" width="25"
                     alt="FlowDash" />
                 <span>Chatbot</span>
             </a>
         </div>

         <h4 class="m-0">Sign up!</h4>
         <p class="mb-3">Create an account with Chatbot</p>

         <form action="{{ route('signup') }}" method="POST">
             @csrf
             <div class="form-group">
                 <label class="text-label" for="name_2">First Name:</label>
                 <div class="input-group input-group-merge">
                     <input id="name_2" type="text" name="fname" class="form-control form-control-prepended"
                         placeholder="Enter your first name" value="{{old('fname')}}" />
                     @error('fname')
                         <span class="invalid-feedback" role="alert">
                             <strong>{{ $message }}</strong>
                         </span>
                     @enderror
                     <div class="input-group-prepend">
                         <div class="input-group-text">
                             <span class="far fa-user"></span>
                         </div>
                     </div>
                 </div>
             </div>

             <div class="form-group">
                 <label class="text-label" for="email_2">Email Address:</label>
                 <div class="input-group input-group-merge">
                     <input id="email_2" type="email" name="email" class="form-control form-control-prepended"
                         placeholder="Enter your email address" value="{{old('email')}}" />
                     @error('email')
                         <span class="invalid-feedback" role="alert">
                             <strong>{{ $message }}</strong>
                         </span>
                     @enderror
                     <div class="input-group-prepend">
                         <div class="input-group-text">
                             <span class="far fa-envelope"></span>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="form-group">
                 <label class="text-label" for="password_2">Password:</label>
                 <div class="input-group input-group-merge">
                     <input id="password_2" type="password" name="password" class="form-control form-control-prepended"
                         placeholder="Enter your password" />
                     @error('password')
                         <span class="invalid-feedback" role="alert">
                             <strong>{{ $message }}</strong>
                         </span>
                     @enderror
                     <div class="input-group-prepend">
                         <div class="input-group-text">
                             <span class="fas fa-lock"></span>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="form-group">
                 <label class="text-label" for="password_2">Confirm Password:</label>
                 <div class="input-group input-group-merge">
                     <input id="password_2" type="password" name="confirm_password"
                         class="form-control form-control-prepended" placeholder="Enter confirm password" />
                     @error('confirm_password')
                         <span class="invalid-feedback" role="alert">
                             <strong>{{ $message }}</strong>
                         </span>
                     @enderror
                     <div class="input-group-prepend">
                         <div class="input-group-text">
                             <span class="fas fa-lock"></span>
                         </div>
                     </div>
                 </div>
             </div>

             <div class="form-group ">
                 <div class="custom-control custom-checkbox">
                     <input type="checkbox" checked="" class="custom-control-input" id="terms" />
                     <label class="custom-control-label" for="terms">I accept
                         <a href="#">Terms and Conditions</a>
                     </label>
                 </div>
             </div>
             <div class="form-group text-center">
                 <button class="btn btn-primary mb-2" type="submit"> Create Account</button><br />
                 <a class="text-body text-underline" href="{{ route('login') }}">Have an account? Login</a>
             </div>
         </form>
     </div>
 @endsection
