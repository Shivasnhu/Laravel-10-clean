<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{User};
use Illuminate\Support\Facades\{Auth, Hash, DB, File, Log};
use \Carbon\Carbon;
use Illuminate\Support\{Str};

class AuthController extends Controller
{

    public function loginForm(Request $request)
    {
        if (\request()->isMethod('get')) {
            return back()->with('error', 'Under Construction');
        } else {
            return back()->with('error', 'Under Construction');
        }
    }
}
